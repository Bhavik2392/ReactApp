import React from "react";

const Titles = () => (
    //Display TiTles for the application(Left Side of Container)
    <div>
        <h1 className="title-container__title">Restaurant Finder</h1>
        <h3 className="title-container__subtitle">Find out Restaurant, by city</h3>
    </div>
);
export default Titles;
