1] How long did you spend on the coding test? What would you add to your solution if you had more time? If you didn't spend much time on the coding test then use this as an opportunity to explain what you would add.
-> I spend approximately 5 hours on a features that are required in my coding test and additional 1 hour for adding image  and styling UI design. I spend much of my time learning some new technique and learning programming language. I enjoy solving difficult problems. I am ambitious and driven. I thrive on challenge and constantly set goals for myself, so I have something to strive toward. I’m not comfortable with settling, and I’m always looking for an opportunity to do better and achieve greatness.


2] What was the most useful feature that was added to the latest version of your chosen language? Please include a snippet of code that shows how you've used it.
->I spend more time on organizing fetch data from api. I added new scrolling feature that will scroll through all record inside container. I had spend most of the time for getting this feature work.
<img src=".\img\screenshot.JPG" />

3] How would you track down a performance issue in production? Have you ever had to do this?
-> I prefer not to have performance monitoring in my production code. I try to have pretty good unit test coverage (every significant method has at least one unit test).For a web application, timing individual requests is a good start. I always use firebug for testing purpose. Firebug works well for that. If you combine that with suggestion to rely on unit tests, then you should be able to locate most of the bottlenecks.

4] How would you improve the API that you just used? 
-> I used this openTable Api for fetching restaurant data. I had used only the api link but i havnt register in Opentable for using API. So i can use minimal ammount of feature due to that so i future i will try to implement this app with my own credentials and use all premium feature.

5] Please describe yourself using JSON
-> I am passionate about my work. Because I love what I do, I have a steady source of motivation that drives me to do my best. In my last job, this passion led me to challenge myself daily and learn new skills that helped me to do better work. For example, I taught myself how to write code with React to make a good UI. I soon became the go-to person for any design needs.
I am very much familier with JSON as i studied about this during my academic term and also during completing my project. So i am good at organizing and fetching JSON data.
I always looking for an opportunity for learnig some new skill from the challenges.


